/********************************
* Author(s): jsmartfo (james j smart-foster) && gcrouch (glenn a crouch)
* Date: 13-December-2010
* 
*********************************/

if (IDE == null || typeof(IDE) == "undefined") { var IDE = new Object(); }


/*********************************
* IDE.CardSelector
* init(), addObservers(), setupSelector(), nextCardSwap(), previousCardSwap()
* EXAMPLE PROTO control for Jonathan/Amanda to see - alteration of card swap 
*********************************/

IDE.CardSelector = {
  nextCard:$('#next-card'),
  previousCard:$('#previous-card'),
  cardElements:$('#card-selector div.card img'),
  cardContainer:$('#card-selector div.card'),
  cardHeading:$('#card-name'),
  cardNumber:$('#card-no'),
  cardDisplayed:null,
  init:function(){
    IDE.CardSelector.addObservers();
    IDE.CardSelector.setupSelector();
  },
  addObservers:function(){
    IDE.CardSelector.nextCard.bind('click', function(e) {
      IDE.CardSelector.nextCardSwap();
    });
    IDE.CardSelector.previousCard.bind('click', function(e) {
      IDE.CardSelector.previousCardSwap();
    });
  }, 
  setupSelector:function(){
    IDE.CardSelector.cardElements.each(function(index){
      if (index != 0)
        $(this).hide();
      else 
        IDE.CardSelector.cardDisplayed = $('#'+$(this).attr('id'));
        IDE.CardSelector.cardHeading.html($(this).attr('alt'));
    });
  },
  nextCardSwap:function(){
    IDE.CardSelector.cardDisplayed.fadeOut('slow', function() {
      IDE.CardSelector.cardDisplayed.next().fadeIn('slow', function() {
        IDE.CardSelector.cardContainer.append(IDE.CardSelector.cardDisplayed);
        IDE.CardSelector.cardHeading.html($(this).attr('alt'));
        IDE.CardSelector.cardNumber.html($(this).attr('title'));
        IDE.CardSelector.cardDisplayed = $('#'+$(this).attr('id'));
      }); 
    });
  },
  previousCardSwap:function(){
   
  }
};

/*********************************
* IDE.FeatureBoxManager
* init(), addObservers(), closeOpenModules(), initialiseGraphList(), toggleGraphList()
* controls right modules and their functionality, upon click of feature box it will pull in graph framework
* toggleGraphList() controls graphing and lists inside feature box - ul li a <-- controls the div.list||graph <-- these will show hide accordingly to click
*********************************/

IDE.FeatureBoxManager = {
  expandableModules: $('#column-two div.feature-box.expandable .head a'),
  graphList: $('#column-two .content ul.toggle-graph-list li a'),
  graphListClicked: null,
  graphingDownloaded: false,
  init:function(){
    IDE.FeatureBoxManager.closeOpenModules();
    IDE.FeatureBoxManager.addObservers();
    IDE.FeatureBoxManager.initialiseGraphList();
  },
  addObservers:function(){
    $(IDE.FeatureBoxManager.expandableModules).click(function(e) {     
      IDE.FileDownload.loadScript('highcharts','./js/HighCharts/highcharts.js');  
      IDE.FileDownload.loadScript('ide-graph-lib','./js/HighCharts/ide-graph-lib.js', function() {
        IDE.GraphManager.init();  
      });        
      var $ariaExpansion = $('#'+$(this).toggleClass('close').attr('aria-controls'));
      $ariaExpansion.slideToggle(function() {
        if ($ariaExpansion.attr('aria-expanded') == 'false') { 
          $ariaExpansion.attr('aria-expanded', 'true'); // region is collapsed
          $ariaExpansion.focus();
        }
        else { 
          $ariaExpansion.attr('aria-expanded', 'false'); // region is expanded
        }
      });
      e.preventDefault();         
    });
    $(IDE.FeatureBoxManager.graphList).click(function(e) {
      IDE.FeatureBoxManager.graphListClicked = $(this);
      IDE.FeatureBoxManager.toggleGraphList();
      e.preventDefault();
    });
  },
  closeOpenModules:function(element){
    if (element) {
      // close specfic element (to be added)       
    } else {
      // close all and add aria piece
      $(IDE.FeatureBoxManager.expandableModules).removeClass('close').parent().next('div.content').attr({'aria-expanded':'false',tabindex:'-1'}).hide();
    }
  }, 
  initialiseGraphList:function(){
    // hide all of the data-graph-list
    $('#column-two .content .data-graph-list').each(function() {
      $(this).hide();
    });
    // for every toggle anchor grab its visibility and show if needs be
    $('#column-two .content ul.toggle-graph-list li a.active').each(function() {
      // get href and then get child and show / hiding partners child
      var element = $(this).attr('href').replace('#', '');
      $(this).parent().parent().siblings('.'+element).toggle();
    });      
  },
  toggleGraphList:function(){
    if (!IDE.FeatureBoxManager.graphListClicked.hasClass('active')) { 
      // turn off previous element - then add class to element clicked
      var contentHide = IDE.FeatureBoxManager.graphListClicked.parent().parent().find('li a.active').toggleClass('active').attr('href').replace('#', ''); // <-- hide previous shown element   
      IDE.FeatureBoxManager.graphListClicked.parent().parent().parent().find('.'+contentHide).toggle();
      IDE.FeatureBoxManager.graphListClicked.toggleClass('active'); // <--- show element clicked
      // get href and toggle content      
      var element = IDE.FeatureBoxManager.graphListClicked.attr('href').replace('#', ''); 
      IDE.FeatureBoxManager.graphListClicked.parent().parent().siblings('.'+element).toggle();
      // call renderGraph
      IDE.Graph.renderGraph(IDE.FeatureBoxManager.graphListClicked.attr('id'));
    }
  }
  
};

/*********************************
* IDE.Graph
* init(), renderGraph()
* creates a graph object when called, pass it graphLinkID, divID, tableID, color, type <--- all of which are parameterised options for the graph
* graphLinkID - ID in DOM that references this graph object, divID - the div you will be replacing (squirting graph into), tableID - ID of table driving graph (the dataset), color - color options for chart (GraphManager contains these), type - chart type you want (pie etc)
*********************************/
IDE.Graph = {
  init:function(graphLinkID, divID, tableID, color, type){
    this.graphLinkID = graphLinkID;
    this.divID = divID;
    this.tableID = tableID;
    this.color = color;
    this.type = type;
  },
  renderGraph:function(graphLinkID){
    $.each(IDE.GraphManager.graphs, function(index,value){
      if(value.graphLinkID == graphLinkID) {
        var table = $('#' + value.tableID);
        IDE.visualizeGraph(table, value.divID, IDE.summaryPieChartOptions, value.color, value.type);
      }
    });
  }
};

/*********************************
* IDE.GraphManager
* init(), graphs array - each graph object above gets added to, colors - some color options for our graphs
* init() - calls IDE.Graph passing all details for object
*********************************/

IDE.GraphManager = {
  graphs: [],
  orange: {
    colors: ['#FBDED0','#EF6820','#FBD39D','#5F2407','#F8BDA0','#8E370B','#F49D71'] //7 color orange scheme
  },
  purple: {
    colors: ['#CB499A','#F4D7E9','#280B1D','#E9AFD3','#50163A','#D35FA8','#A02C75'] //7 color purple scheme
  },
  init:function(){ 
    // create each graph object
    IDE.GraphManager.graphs.push(new IDE.Graph.init('categories-graph-link','ide-categories-pie', 'ide-categories-summary',IDE.GraphManager.orange,'pie'));
    IDE.GraphManager.graphs.push(new IDE.Graph.init('merchants-graph-link','ide-merchants-pie', 'ide-merchants-summary',IDE.GraphManager.purple,'pie'));
  }
};

/*********************************
* IDE.AdvancedSearch
* init(), addObservers(), toggleSubCategories(), removeListElement(), addListElement(), cloneCategoryList()
* creates the advanced search handler, clones the list of categories on load and the hides the cloned version, each item will be diaply block upon click of add or remove button
*********************************/

IDE.AdvancedSearch = {
  parentCategories:$('#advanced-search ul > li > a.icon'),
  addedCategories:$('#advanced-search-selected'),
  cancelAdvancedSearch:null,
  listingCategory:null,
  categoryClicked:null,
  init:function(){
    IDE.AdvancedSearch.cloneCategoryList();
    IDE.AdvancedSearch.addObservers();
  },
  addObservers:function(){
    IDE.AdvancedSearch.parentCategories.live('click', function(e) { 
      IDE.AdvancedSearch.categoryClicked = $(this);
      IDE.AdvancedSearch.toggleSubCategories();
      e.preventDefault();
    });
    $('#advanced-search-selection ul, #advanced-search-selected ul').selectable({ 
      filter: 'a',
      cancel: 'a.icon,:input,option'
    });
    $('#advanced-search-button-add').live('click', function(e) { 
      IDE.AdvancedSearch.addListElement();
      e.preventDefault();
    });
    $('#advanced-search-button-remove').live('click', function(e) { 
      IDE.AdvancedSearch.removeListElement();
      e.preventDefault();
    });
    $('#advanced-search-cancel').live('click', function(e) { 
      IDE.LightboxModalManager.hideLightboxLayer();
    });
  },
  updateListObserver:function(){

  },
  toggleSubCategories:function(){
    IDE.AdvancedSearch.categoryClicked.find('span').toggleClass('collapse expand').parent().siblings('ul').slideToggle();
  },
  removeListElement:function(){
    // for every element with class selected get the id and sets its inLaw element
    $('#advanced-search-selected .ui-selected').each(function(index) {
      $('#'+$(this).parent().attr('id')).hide();
      if('#advanced-search-selected > ul > li > a.ui-selected') {
        $liElement = $('#'+$(this).parent().attr('id')).hide();
        if ($liElement.parents().filter('ul').length > 1) {
          // console.log('child do check for siblings so maybe hide parent');
        } else {
          // console.log('not a child but parent so hide all children');
        }
      }
    });
  },
  addListElement:function(){    
    // for every element with class selected get the id and sets its inLaw element
    $('#advanced-search-selection .ui-selected').each(function(index) {
      // show appropriate category
      $elementInLaw = $('#'+$(this).parent().attr('id')+'-sel').show();
      // does this have a parent category 
      if ($elementInLaw.parents().filter('ul').length > 1){
        if ($(this).parent().parent().parent().find('> a').hasClass('ui-selected')) {
          // console.log('Parent and child on their own :-) ');          
        }
        // console.log('I will show the parent...')        
        // this is a child element so grab parent li, and display parent also
        $elementInLaw.closest('li.category').show();
      } else if( $ ('#advanced-search-selection > ul > li > a.ui-selected')  && $ ('#advanced-search-selection > ul > li > ul > li > a.ui-selected').length == 0){
        // console.log('I will show all other children')
        $elementInLaw.find('li').each(function(index) {
          $(this).show();
        });
      }
    });
  }, 
  cloneCategoryList:function(){
    IDE.AdvancedSearch.listingCategory = $('#advanced-search-selection > ul').clone()
    IDE.AdvancedSearch.listingCategory.find('li').each(function(index) {
      if (this.id) this.id = this.id+'-sel';  
    }).end().attr('id', 'clone-sel').appendTo('#advanced-search-selected');
  }
};

/*********************************
* IDE.FileDownload
* loadScript(), loadCSS(), loadHTML(), inDownloadList() <-- test for files already pulled 
* this generic functionality to pull in scripts and CSS for IDE pages. It checks also if downloaded previously -- if is DL previous it does nothing.
*********************************/

IDE.FileDownload = {
  fileDownloadList: [],
  defaultCallback:function(){},
  loadScript:function(id, url, callback){ 
    if(callback == null) { callback = IDE.FileDownload.defaultCallback; }
    if(IDE.FileDownload.inDownloadList(id) > -1){
      return false;
    } else {
      $.getScript(url, function() {      
        IDE.FileDownload.fileDownloadList.push(id); // add to fileDownloadList array
        callback(); // make callback
      });      
    }
  }, 
  inDownloadList:function(id){   
    return $.inArray(id, IDE.FileDownload.fileDownloadList);
  }, 
  loadCSS:function(id, url, callback){
    // this will do similar to above but not using $.getScript
  },
  loadHTML:function(id, url, callback){
    if(callback == null) { callback = IDE.FileDownload.defaultCallback; }
    $.ajax({
      url: url,
      success: function(data){
        IDE.FileDownload.fileDownloadList.push(id); // add to fileDownloadList array
        callback(data); // make callback passing out data    
      }
    });
  }
};

/*********************************
* IDE.Popout
* init(), addObservers(), displayPopoutcontent()
* controls all popout bubbles, must have anchor classed as 'popout-control' with following div classed as 'popout-content'
* an open class is added/removed to anchor upon click
*********************************/

IDE.Popout = { 
  popoutElements: $('a.popout-control'),
  elementClicked: null,
  offset: null,
  init:function(){
    IDE.Popout.addObservers();
  },  
  addObservers:function(){
    $(IDE.Popout.popoutElements).click(function(e) {
      IDE.Popout.offset = $(this).children('span.popout-twiggy').offset();
      IDE.Popout.elementClicked = this;
      IDE.Popout.displayPopoutContent();
      e.preventDefault();
    });    
  },
  displayPopoutContent:function(){
    $(IDE.Popout.elementClicked).toggleClass('open').next('div.popout-content').toggle().css({'left' : IDE.Popout.offset.left +$(IDE.Popout.elementClicked).children('span.popout-twiggy').outerWidth()-1, 'top' : IDE.Popout.offset.top});
  }
};

/*********************************
* IDE.Search
* init(), addObservers(), resetSearchBox()
* controls right modules and their functionality
*********************************/

IDE.Search = {
  searchBox: $('#search-transactions'),
  searchBoxPrompt: null, 
  predictiveSearchArea:$('#ide-suggested-search'),
  init:function(){
    // jQuery doesnt support defaultValue without plugin - this is the fix
    IDE.Search.searchBox.attr('value', function() { 
      IDE.Search.searchBox.val(IDE.Search.searchBoxPrompt = this.defaultValue); 
      IDE.Search.addObservers();
    });
  },
  addObservers:function(){
    $(IDE.Search.searchBox).bind("focus", function(event) {
      if ($(this).val() == IDE.Search.searchBoxPrompt) {
        $(this).val(''); 
      }
    }).bind("blur", function(event) {
      IDE.Search.resetSearchBox();
      IDE.Search.predictiveSearchArea.fadeOut();
    });
    // bind keydown event
    $(IDE.Search.searchBox).keydown(function() {
      if ($(this).val().length > 1) {
        IDE.Search.predictiveSearchArea.fadeIn();
      } else if ($(this).val().length < 1) {
        IDE.Search.predictiveSearchArea.fadeOut();
      }
    });
  },
  resetSearchBox:function(){
    if ($(IDE.Search.searchBox).val() == '') {
      $(IDE.Search.searchBox).val(IDE.Search.searchBoxPrompt);
    }
  }
};

/*********************************
* IDE.CardSummaryManager
* init(), calculatePercentage(), roundPercentage(), setupCardSummaryLine()
* controls card summary graphical credit limit/balance display, works out percentage then rounds it to whatever degree specified, 
* once it has calculated it will alter classes accordingly - CSS handles the rest.
* TO DO -- IE doesnt like parseFloat -- fix this

  creditLimit: parseFloat($('#balance-end p').text().trim().replace(/[^a-zA-Z 0-9]+/g,'')),
  currentBalance: parseFloat($('#current-balance-box h3 span').text().trim().replace(/[^-]/,'')).toFixed(0),

*********************************/ 

IDE.CardSummaryManager = {
  creditLimit: parseFloat($('#balance-end p').text().replace(/[^a-zA-Z 0-9]+/g,'')),
  currentBalance: parseFloat($('#current-balance-box h3 span').text().replace(/[^-]/,'')).toFixed(0),
  percentage:null,
  init:function(){
    IDE.CardSummaryManager.calculatePercentage();
    IDE.CardSummaryManager.setupCardSummaryLine();
  },
  calculatePercentage:function(){
    // works out % but will be decimal pointed and not to 10th degree eg: 10, 20, 30, 40, 50
    IDE.CardSummaryManager.percentage = (IDE.CardSummaryManager.currentBalance/IDE.CardSummaryManager.creditLimit)*100;
    // this works out the rounded % to 10th degree - eg 34.4% rounds to 40% -- 10 is passed to roundPercentage() method
    IDE.CardSummaryManager.percentage = IDE.CardSummaryManager.roundPercentage(Math.round(IDE.CardSummaryManager.percentage), 10);
  },
  roundPercentage:function(number, degree){
    return Math.ceil(number/degree)*degree;
  },
  setupCardSummaryLine:function(){
    if (IDE.CardSummaryManager.percentage < 0) {
      // number % spent is negative eg: under credit
      $('#current-balance-line').addClass('percent'+IDE.CardSummaryManager.percentage).addClass('negative');
    } else if (IDE.CardSummaryManager.percentage > 100){
      // number is a super-positive eg: over credit limit, set to string and remove first char - giving u a % value
      $('#current-balance-line').addClass('percent-'+IDE.CardSummaryManager.percentage.toString().substr(1)).addClass('positive');
    } else {
      // typical scenario eg: within credit
      $('#current-balance-line').addClass('percent-'+IDE.CardSummaryManager.percentage);
    }
  }
};

/*********************************
* IDE.LightboxModalManager
* init(), addObservers(), 
* manages display of the modal layers
*********************************/

IDE.LightboxModalManager = {
  lightboxAnchors: $('a.lightbox-modal'),
  closeAnchor: $('#close-layer'),
  layerDivert: $('#layer-divert'),
  elementClicked: null,
  width: null,
  top: 200,
  displayArea: 0,
  modalData: null,
  url: null,
  init:function(){
    IDE.LightboxModalManager.addObservers();
  },
  addObservers:function(){
    IDE.LightboxModalManager.lightboxAnchors.click(function(e) {
      IDE.LightboxModalManager.elementClicked = $(this);
      IDE.LightboxModalManager.getLightboxPreferences();
      e.preventDefault();
    });
    IDE.LightboxModalManager.closeAnchor.live('click', function(e) {
      IDE.LightboxModalManager.hideLightboxLayer();
      e.preventDefault();
    });
    IDE.LightboxModalManager.layerDivert.live('focus', function(e) {
      $('#popup').focus();
    });
  },
  getLightboxPreferences:function(){
    IDE.LightboxModalManager.width = IDE.LightboxModalManager.captureParameter('width',IDE.LightboxModalManager.elementClicked.attr('href'));
    IDE.LightboxModalManager.displayArea = IDE.LightboxModalManager.captureParameter('display',IDE.LightboxModalManager.elementClicked.attr('href'));
    IDE.LightboxModalManager.url = IDE.LightboxModalManager.elementClicked.attr('href');
    IDE.FileDownload.loadHTML(IDE.LightboxModalManager.url, IDE.LightboxModalManager.url, function(data) {
      IDE.LightboxModalManager.modalData = data;
      IDE.LightboxModalManager.generateLightboxLayer();
    });     
  },
  hideLightboxLayer:function(){
    $('#layer, #popup').fadeOut(function(){
      $(this).remove();
      IDE.LightboxModalManager.elementClicked.focus(); // return focus to element clicked -- so user doesnt lose way
    });
  },
  captureParameter:function(name, source){
    var results = new RegExp('[\\?&]' + name + '=([^&#]*)').exec(source);
    if (!results) { return 0; }
    return results[1] || 0;
  },
  generateLightboxLayer:function(){
    if (IDE.LightboxModalManager.displayArea == 0) {
      $('<div id="layer"></div><div id="popup"><div class="popup-header"><div class="right"><a class="icon" id="close-layer" href="#"><span class="cancel"></span>Close</a></div></div><div id="popup-content" class="clearfix">' +IDE.LightboxModalManager.modalData +'</div><a href="#" id="layer-divert"></a></div>').appendTo('body');
      // setup the widths and other properties and fade in - IE hack with opacity and width below
      $('#layer').css({filter:'alpha(opacity=40)'}).fadeIn();
      $('#popup').width(IDE.LightboxModalManager.width).css({top:'50%', left:'50%', margin:'-'+($('#popup').height() / 2)+'px 0 0 -'+($('#popup').width() / 2)+'px'}).fadeIn().attr({tabindex:'-1'}).focus();  
    } else {
      console.log(IDE.LightboxModalManager.displayArea);
      $(IDE.LightboxModalManager.modalData).appendTo('#'+IDE.LightboxModalManager.displayArea);
    }
  }  
};

/*********************************
* IDE.AJAXManager
* init(), addObservers(), 
* manages all AJAX requests
*********************************/

IDE.AJAXManager = {
  init:function(url){
    
  }
};

/*********************************
* IDE.StatementTableManager
* init(), toggleColumnsOptions(), updateColumns()
* controls the statement data table and adding/removing columns
*********************************/

IDE.StatementTableManager = {
  optionalColumns: $('.optional-column'),
  columnPrefs: [],
  init:function(){
    $("#statement-data-table").tablesorter();
    $("#update-columns-button").click(function(e){ IDE.StatementTableManager.updateColumns(); e.preventDefault(); });
    /*if(IDE.PreferencesManager.getPreferences() !== null && IDE.PreferencesManager.getPreferences() !== undefined){
      IDE.StatementTableManager.columnPrefs = IDE.PreferencesManager.getPreferences().split("|");
    }*/
    IDE.StatementTableManager.initColumnDisplay();
  },
  initColumnDisplay:function(){
    if(IDE.StatementTableManager.columnPrefs !== ''){
      for(x = 0; x < IDE.StatementTableManager.optionalColumns.length; x++){ 
        var columnHeaderId = IDE.StatementTableManager.optionalColumns[x].id;
        var columnCells = $('.' + columnHeaderId);
        if(IDE.StatementTableManager.columnPrefs[x] == "1"){
          $('#' + columnHeaderId).show();
          $(columnCells).show();
        }
        else{
          $('#' + columnHeaderId).hide();
          $(columnCells).hide();
        }
      }
    }
  },
  updateColumns:function(){
    // call to layer toggle but add in override of element to close
    IDE.Popout.displayPopoutContent();
    for(x = 0; x < IDE.StatementTableManager.optionalColumns.length; x++){ 
      //get column header & cells
      var columnHeaderId = IDE.StatementTableManager.optionalColumns[x].id;
      var columnCells = $('.' + columnHeaderId);
      //show column if option checkbox is checked
      if($('#' + columnHeaderId + '-option:checked').val() !== undefined){
        $('#' + columnHeaderId).show();
        $(columnCells).show();
      //  IDE.StatementTableManager.columnPrefs[x] = '1';
      }
      //otherwise hide column
      else{
        $('#' + columnHeaderId).hide();
        $(columnCells).hide();
       // IDE.StatementTableManager.columnPrefs[x] = '0';
      }
    }
   // IDE.PreferencesManager.updatePreferences(IDE.StatementTableManager.columnPrefs.join("|"));
  }
};

/*********************************
* IDE.ChevronManager
* init(), addObservers(), addChevron()
* manages display of the chevrons for search criteria
*********************************/

IDE.ChevronManager = {
  chevronCloseLinks: $('.chevron a'),
  chevronContainer: $('#chevron-filter'),
  init:function(){
    IDE.ChevronManager.addObservers();
  },
  addObservers:function(){
    $(IDE.ChevronManager.chevronCloseLinks).click(function(e) {
      //remove chevron div when X is clicked
      $(this).closest('div').remove();
      e.preventDefault();
    });
  },
  addChevron:function(){
    //IDE.ChevronManager.chevronContainer.add
  }
};

/*********************************
* IDE.ROCExpandableManager
* init(), createRocData(), addObservers()
* controls the statement data table and adding/removing columns
*********************************/

IDE.ROCExpandableManager = {
  rocExpandable: $("#statement-data-table tbody tr td a span.expand"),
  init: function(){
    IDE.ROCExpandableManager.addObservers();
  },
  addObservers: function(e) {
    $(IDE.ROCExpandableManager.rocExpandable).click(function(e){
      var target = $(this).closest('tr');
      $(this).toggleClass('collapse');
      //insert content into the DOM and then toggle class
      //console.log(target);
      if(target.next().hasClass('expand-child')){
        target.next().toggleClass('close');
      } else {
        target.after(IDE.ROCExpandableManager.createRocData());
        $("#statement-data-table").trigger("update");
      }
      e.preventDefault();
    });
  },
  //Should take a JSON object after the AJAX call is returned successfully to generate the 
  //DBD information based on the type of the ROC
  createRocData: function() {
    var enrichedRoc = 
    "<tr class='expand-child'>" +
    "<td headers='roc-details' scope='row'></td>" +
    "<td></td><td colspan='5'>" +
    "<div class='roc-dbd-container clearfix'>" +
      "<div class='roc-dbd'>" +
        "<ul>" +
          "<li>VIRGIN ATLANTIC FLIGHT NO xxxxxxxxxxxxxxxxxxxxxxxxxxx yyyyyyyyyyyyyyyyyy</li>" +
          "<li>ROUNTING NO: XXXXXXXXXXXX</li>" +
          "<li>CLASS: PREMIUM ECONOMY</li>" +
          "<li>FLIGHT FROM: LONDON HEATHROW CARRIER: VA CLASS: E</li>" +
          "<li>FLIGHT TO: CAPE TOWN INTERNATIONAL</li>" +
          "<li>TICKET NUMBER: xxxxxx</li>" +
          "<li>PASSANGER NAME: B BICKERTON</li>" +
          "<li>REFERENCE NO: xxxxxxx</li>" +
        "</ul>" +
      "</div>" + //<div class='roc-offer'>Offers space</div>" +
    "</div>"+
    "<div class='roc-controls clearfix'><div class='roc-category'><a href='#'>General Purchases</a> &gt; <a href='#'>Groceries</a></div><div class='roc-links'><a href='#'>Query this transaction</a><span class='divider'>|</span><a href='#' class='icon'>Print<span class='print'></span></a></div></div>" +   
    "</td></tr>";
    return enrichedRoc;
  }
};

/*********************************
* IDE.DateLayerManager
* init(), initialiseLayer(), addObservers(), restrictRange(), setSelectedDates()
* Controls the Date layer, links the datepickers to the input fields, highlights selected date ranges and restricts selectable date range.
*********************************/
IDE.DateLayerManager = {
  //Initialise Calendar picker date range - **THIS CAN BE DETERMINED BASED ON DATES OF STATEMENTS AVAILABLE
  minDate: '01/01/2010',
  maxDate: '01/01/2012',
  closeCalendar: $('#close-date-link'),
  init:function(){    
    IDE.DateLayerManager.initialiseLayer();
    //Add change observers for input fields
    IDE.DateLayerManager.addObservers();
  },
  initialiseLayer:function(){
    $.get('calendar.html', function(data){ 
      $("#statement-date").append(data); 
      IDE.DateLayerManager.buildDatepickers();
    });
    //On date range click, trigger date layer
    $('#date-layer-link').click(function(){
      $('#date-range-layer').toggle();
    });
  },
  buildDatepickers:function(){
    $('#from-datepicker,#to-datepicker').datepicker({
      onSelect: IDE.DateLayerManager.restrictRange,
      beforeShowDay:IDE.DateLayerManager.setSelectedDates,
      dateFormat: 'dd/mm/yy',//Date format for UK
      dayNamesMin: ['S', 'M', 'T', 'W', 'T', 'F', 'S'],//Day headers format on calendar
      monthNamesShort: ['January', 'February', 
                       'March', 'April', 'May', 
                       'June', 'July', 'August', 
                       'September', 'October', 
                       'November', 'December'],//Month headers format on calendar dropdowns
      firstDay: 1,//Set 1st day of week as Monday
      changeMonth: true,//Enable dropdowns for month
      changeYear: true, //Enable dropdowns for year
      minDate: IDE.DateLayerManager.minDate, //Set restriction on 1st available date in past
      maxDate: IDE.DateLayerManager.maxDate //Set restriction on last available date in future
    });
    //Set related input field for each datepicker
    $('#from-datepicker').datepicker('option','altField','#from-date');
    $('#to-datepicker').datepicker('option','altField','#to-date');
  },
  addObservers:function(){
    $('#from-date,#to-date').change(function() {
      var inputID = $(this).attr('id');
      $('#'+inputID+'picker').datepicker('setDate', $('#'+inputID).val());
      IDE.DateLayerManager.restrictRange($('#'+inputID).val(), this);
    });
    IDE.DateLayerManager.closeCalendar.live('click', function(e) {
      $('#date-range-layer').toggle();
      e.preventDefault();
    });
  },
  restrictRange:function(dates, object) {
    //restrict the min date that can be chosen in the TO picker based on FROM date
    if (object.id == 'from-datepicker' || object.id == 'from-date') { 
      $('#to-datepicker').datepicker('option', 'minDate', dates || null); 
    }
    else {
      $('#from-datepicker').datepicker('refresh');//ensure the from datepicker range is refreshed when to date changes.
    }
  },
  setSelectedDates:function(date){
    var fromDate = $('#from-datepicker').datepicker('getDate');
    var toDate = $('#to-datepicker').datepicker('getDate');
    if(date < fromDate || date > toDate){
       return [true, ''];//remove active class if date falls outside current range
    }
    else{
      return [true, 'ui-state-active'];//add active class if date is between FROM and TO dates.
    }
  }
};

$(document).ready(function() {
  IDE.CardSelector.init();

/*  IDE.FeatureBoxManager.init();
  IDE.StatementTableManager.init();
  IDE.ROCExpandableManager.init();   
  IDE.ChevronManager.init(); 
  IDE.Popout.init(); 
  IDE.Search.init();
  IDE.CardSummaryManager.init();
  IDE.DateLayerManager.init();
  IDE.LightboxModalManager.init();*/
});

/*
TODO
*****
//console.time("timer");   console.timeEnd("timer");  
- Chevrons (optional vs. fixed for dates), 
- Calendar
- Graphing
- Layers/modal windows
- Position of popouts for column add & other cards
- Move current balance indicator above (rather than below tracking line)
- Need to make sorting work with DBD details expanded
*/